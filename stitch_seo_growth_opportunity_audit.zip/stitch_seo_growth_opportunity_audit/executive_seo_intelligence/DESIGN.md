---
name: Executive SEO Intelligence
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a1700'
  on-tertiary-container: '#b87500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 32px
  xl: 48px
  container-max: 1440px
  gutter: 24px
---

## Brand & Style
The design system is engineered for executive-level SEO reporting, prioritizing clarity, authority, and rapid insight. The brand personality is **Professional, Analytical, and Decisive**, mirroring the aesthetic of top-tier management consultancies like McKinsey or Deloitte.

The visual style is **High-End Minimalist SaaS**. It leverages significant whitespace to reduce cognitive load when viewing complex data sets. By avoiding decorative elements in favor of functional geometry and precise typography, the UI directs all focus to key performance indicators (KPIs) and strategic opportunities. The emotional response should be one of "controlled confidence"—the user should feel they are viewing a definitive source of truth.

## Colors
The palette is rooted in corporate authority and data visualization best practices.
- **Deep Navy (#0F172A):** Used for primary headings, navigation, and core data points to establish an executive tone.
- **Success Green (#10B981):** Reserved strictly for positive growth, "Passed" audit states, and high-priority SEO opportunities.
- **Urgency Amber (#F59E0B):** Used for warnings, technical debt indicators, and declining trends.
- **Neutral Slate (#64748B):** Applied to secondary text, axis labels, and supporting metadata to maintain hierarchy.
- **Off-White (#F8FAFC):** The canvas color, providing a soft contrast that reduces eye strain compared to pure white.

## Typography
Inter is the sole typeface, utilized for its exceptional legibility in data-heavy environments. 
- **Numerical Data:** Use tabular num features (`tnum`) for all data tables and metrics to ensure vertical alignment of digits.
- **Hierarchical Contrast:** Use font weight (Semi-Bold/Bold) rather than size increases alone to distinguish sections.
- **Micro-copy:** Labels for chart axes and legends should use `label-caps` in Neutral Slate to remain unobtrusive but accessible.

## Layout & Spacing
The layout follows a **Fixed Grid** model optimized for high-resolution desktop displays (1440px) typical of executive workstations. 
- **Grid:** 12-column system with a 24px gutter. 
- **The Dashboard Header:** A fixed 80px top bar containing the date range picker and global filters.
- **Card Layout:** Content is grouped into logical modules (e.g., "Technical Health," "Content Performance"). Each module spans 4, 6, or 12 columns.
- **Margins:** 32px external margins ensure content doesn't feel cramped against the screen edge.

## Elevation & Depth
This design system avoids heavy drop shadows in favor of **Tonal Layering and Low-Contrast Outlines**.
- **The Surface:** All cards sit on a pure white background (`#FFFFFF`) with a subtle 1px border (`#E2E8F0`).
- **Interaction:** On hover, a card may utilize a very soft ambient shadow (0px 4px 20px rgba(15, 23, 42, 0.05)) to indicate interactivity.
- **Z-Index:** Modals and tooltips are the only elements that use significant elevation, using a medium-diffused shadow to separate from the dashboard layer.

## Shapes
Shapes are **Soft (0.25rem / 4px)**. This subtle rounding maintains a professional, architectural feel while feeling modern.
- **Data Containers:** Use a 4px corner radius for all cards and input fields.
- **Gauges & Progress Bars:** These utilize rounded caps to provide a softer, more "at-a-glance" visual for performance metrics.
- **Data Points:** In line charts, use small circular markers (4px diameter) to denote specific data entries.

## Components
- **Flat Data Cards:** White background, 1px Slate-200 border. Title in Navy (Semi-Bold 14px), Metric in Navy (Bold 32px), with a secondary Trend Sparkline.
- **Trend Sparklines:** Simplified line charts without axes. Primary Navy for neutral trends, Success Green for positive, and Urgency Amber for negative.
- **Professional Gauges:** Semi-circular charts. Use Success Green for 80-100%, Urgency Amber for 0-40%. Gauge thickness should be a slim 8px.
- **Data Tables:** Clean, no vertical borders. Header row has a light Slate-50 background. Row height is 48px to allow for comfortable scanning. 
- **Status Chips:** Small, low-saturation backgrounds with high-saturation text (e.g., Light Green background with Deep Green text) for audit statuses like "Optimized" or "Issue Found."
- **Primary Buttons:** Deep Navy background with White text. Rectangular with 4px radius. No gradients.